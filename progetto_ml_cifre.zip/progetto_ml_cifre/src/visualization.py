from pathlib import Path
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay


def save_confusion_matrix(model, X_test, y_test, output_path):
    """
    Genera e salva la confusion matrix del modello scelto.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(8, 8))
    ConfusionMatrixDisplay.from_estimator(
        model,
        X_test,
        y_test,
        cmap="Blues",
        ax=ax
    )

    ax.set_title("Confusion Matrix - Modello migliore")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)


def save_example_predictions(digits, model, output_path, n=10):
    """
    Salva una figura con alcune immagini e le relative previsioni.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    images = digits.images[:n]
    data = digits.data[:n]
    true_labels = digits.target[:n]
    predictions = model.predict(data)

    fig, axes = plt.subplots(2, 5, figsize=(10, 5))

    for ax, image, true_label, predicted_label in zip(
        axes.ravel(), images, true_labels, predictions
    ):
        ax.imshow(image, cmap="gray")
        ax.set_title(f"Vero: {true_label} | Pred: {predicted_label}")
        ax.axis("off")

    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
