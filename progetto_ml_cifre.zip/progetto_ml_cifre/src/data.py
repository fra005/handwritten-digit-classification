from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split


def load_data(test_size=0.2, random_state=42):
    """
    Carica il dataset digits e divide i dati in training e test set.
    """
    digits = load_digits()

    X = digits.data
    y = digits.target

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=test_size,
        random_state=random_state,
        stratify=y
    )

    return digits, X_train, X_test, y_train, y_test
