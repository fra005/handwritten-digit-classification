from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC


def get_models():
    """
    Restituisce i modelli che verranno confrontati.
    """
    models = {
        "Logistic Regression": Pipeline([
            ("scaler", StandardScaler()),
            ("model", LogisticRegression(max_iter=2000, random_state=42))
        ]),

        "KNN": Pipeline([
            ("scaler", StandardScaler()),
            ("model", KNeighborsClassifier(n_neighbors=5))
        ]),

        "Random Forest": RandomForestClassifier(
            n_estimators=200,
            random_state=42
        ),

        "SVM": Pipeline([
            ("scaler", StandardScaler()),
            ("model", SVC(kernel="rbf", C=10, gamma="scale"))
        ])
    }

    return models


def train_models(models, X_train, y_train):
    """
    Addestra tutti i modelli.
    """
    trained_models = {}

    for name, model in models.items():
        print(f"Addestramento: {name}")
        model.fit(X_train, y_train)
        trained_models[name] = model

    return trained_models
