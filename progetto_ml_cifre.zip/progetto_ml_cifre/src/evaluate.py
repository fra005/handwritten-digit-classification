import pandas as pd
from sklearn.metrics import accuracy_score, classification_report


def evaluate_models(models, X_test, y_test):
    """
    Calcola l'accuracy di ogni modello e restituisce una tabella ordinata.
    """
    results = []

    for name, model in models.items():
        predictions = model.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)

        results.append({
            "Modello": name,
            "Accuracy": accuracy
        })

    results_df = pd.DataFrame(results)
    results_df = results_df.sort_values(
        by="Accuracy",
        ascending=False
    ).reset_index(drop=True)

    return results_df


def print_best_model_report(model_name, model, X_test, y_test):
    """
    Stampa un report più dettagliato per il modello migliore.
    """
    predictions = model.predict(X_test)

    print("\nReport di classificazione")
    print("-" * 50)
    print(f"Modello: {model_name}")
    print(classification_report(y_test, predictions))
